<?php
print "Trigger builds with image stream \n";
?>
