package com.redhat.training.rest;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("/todo/api")
public class RestApplication extends Application {
}
