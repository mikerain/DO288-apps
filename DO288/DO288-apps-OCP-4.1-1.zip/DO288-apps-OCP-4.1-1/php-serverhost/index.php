<?php
print "I am running on server " . gethostname() . "\n";
?>
