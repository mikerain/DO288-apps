This front-end app is hard-coded to access the back-end at:
http://todoapp.apps.lab.example.com
